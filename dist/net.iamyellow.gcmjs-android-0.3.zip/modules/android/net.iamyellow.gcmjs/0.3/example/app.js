/*global Ti: true, alert: true, require: true, setInterval: true */

(function () {	
	require('controller').start();
})();
