var gcm = require('net.iamyellow.gcmjs');
gcm.registerForPushNotifications({
	success: function (ev) {
		Ti.API.info('******* success, ' + ev.deviceToken);
	},
	error: function (ev) {
		Ti.API.info('******* error, ' + ev.error);
	},
	callback: function () {
		alert('hola??');
	}
});
