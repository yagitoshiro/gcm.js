!function(activity, gcm) {
    Ti.API.info("gcm_activity.js");
    var intent = activity.intent;
    var ntfId = 0;
    var title = "";
    var message = "";
    var appdata = {};
    intent.hasExtra("title") && (title = intent.getStringExtra("title", ""));
    intent.hasExtra("message") && (message = intent.getStringExtra("message", ""));
    intent.hasExtra("appdata") && (appdata = intent.getStringExtra("appdata", ""));
    intent.hasExtra("ntfId") && (ntfId = intent.getIntExtra("ntfId", 0));
    gcm.data = {
        ntfId: ntfId,
        title: title,
        message: message,
        appdata: appdata
    };
    Ti.API.info(String.format("gcm.data:", gcm.data || {}));
    if (gcm.isLauncherActivity) {
        var mainActivityIntent = Ti.Android.createIntent({
            className: gcm.mainActivityClassName,
            packageName: Ti.App.id,
            flags: Ti.Android.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED | Ti.Android.FLAG_ACTIVITY_SINGLE_TOP
        });
        mainActivityIntent.addCategory(Ti.Android.CATEGORY_LAUNCHER);
        activity.startActivity(mainActivityIntent);
    } else activity.finish();
}(Ti.Android.currentActivity, require("net.iamyellow.gcmjs"));