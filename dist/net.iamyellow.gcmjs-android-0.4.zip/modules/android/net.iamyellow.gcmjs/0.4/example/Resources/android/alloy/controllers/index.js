function __processArg(obj, key) {
    var arg = null;
    if (obj) {
        arg = obj[key] || null;
        delete obj[key];
    }
    return arg;
}

function Controller() {
    function doClick() {
        deviceToken && alert("do unregister");
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "index";
    this.args = arguments[0] || {};
    if (arguments[0]) {
        {
            __processArg(arguments[0], "__parentSymbol");
        }
        {
            __processArg(arguments[0], "$model");
        }
        {
            __processArg(arguments[0], "__itemTemplate");
        }
    }
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.container = Ti.UI.createWindow({
        backgroundColor: "white",
        id: "container"
    });
    $.__views.container && $.addTopLevelView($.__views.container);
    $.__views.label = Ti.UI.createLabel({
        width: Ti.UI.SIZE,
        height: Ti.UI.SIZE,
        color: "#000",
        font: {
            fontSize: 12
        },
        text: "unregist device",
        id: "label"
    });
    $.__views.container.add($.__views.label);
    doClick ? $.__views.label.addEventListener("click", doClick) : __defers["$.__views.label!click!doClick"] = true;
    exports.destroy = function() {};
    _.extend($, $.__views);
    var deviceToken = "";
    $.container.open();
    var gcm = require("net.iamyellow.gcmjs");
    var pendingData = gcm.data;
    pendingData && null !== pendingData && Ti.API.info("******* data (started) " + JSON.stringify(pendingData));
    var receivePush = function(ev) {
        Ti.API.info(String.format("receivePush %s", ev.appdata || {}));
        alert(String.format("receivePush", ev.appdata || {}));
    };
    var deviceTokenSuccess = function(ev) {
        Ti.API.info("deviceTokenSuccess:" + ev.deviceToken);
        deviceToken = ev.deviceToken;
    };
    var deviceTokenError = function(ev) {
        Ti.API.info("deviceTokenError:" + ev.error);
    };
    var dataWhenResume = function(ev) {
        Ti.API.info(String.format("ev.data %s", ev.data));
    };
    var afterUnregister = function(ev) {
        Ti.API.info(String.format("afterUnregister %s", ev));
        Ti.API.info("******* unregister " + ev.deviceToken);
        deviceToken = "";
    };
    var isCallbackMethod = false;
    if (isCallbackMethod) gcm.registerForPushNotifications({
        callback: receivePush,
        success: deviceTokenSuccess,
        error: deviceTokenError,
        unregister: afterUnregister,
        data: dataWhenResume
    }); else {
        gcm.addEventListener("callback", receivePush);
        gcm.addEventListener("success", deviceTokenSuccess);
        gcm.addEventListener("error", deviceTokenError);
        gcm.addEventListener("data", dataWhenResume);
        gcm.addEventListener("unregister", afterUnregister);
        gcm.registerForPushNotifications({});
    }
    __defers["$.__views.label!click!doClick"] && $.__views.label.addEventListener("click", doClick);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;