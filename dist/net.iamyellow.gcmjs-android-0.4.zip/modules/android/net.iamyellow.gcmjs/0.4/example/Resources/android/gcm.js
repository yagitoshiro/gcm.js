!function(service) {
    var serviceIntent = service.getIntent();
    var title = serviceIntent.hasExtra("title") ? serviceIntent.getStringExtra("title") : "";
    var appdata = serviceIntent.hasExtra("appdata") ? serviceIntent.getStringExtra("appdata") : "";
    var message = serviceIntent.hasExtra("message") ? serviceIntent.getStringExtra("message") : "";
    var notificationId = function() {
        var str = "", now = new Date();
        var hours = now.getHours(), minutes = now.getMinutes(), seconds = now.getSeconds();
        str += (hours > 11 ? hours - 12 : hours) + "";
        str += minutes + "";
        str += seconds + "";
        var start = new Date(now.getFullYear(), 0, 0), diff = now - start, oneDay = 864e5, day = Math.floor(diff / oneDay);
        str += day * (hours > 11 ? 2 : 1);
        var ml = now.getMilliseconds() / 100 | 0;
        str += ml;
        Ti.API.info("service gcm.js str :" + str);
        return 0 | str;
    }();
    var ntfId = Ti.App.Properties.getInt("ntfId", 0), launcherIntent = Ti.Android.createIntent({
        className: "net.iamyellow.gcmjs.GcmjsActivity",
        action: "action" + ntfId,
        packageName: Ti.App.id,
        flags: Ti.Android.FLAG_ACTIVITY_NEW_TASK | Ti.Android.FLAG_ACTIVITY_SINGLE_TOP
    });
    launcherIntent.addCategory(Ti.Android.CATEGORY_LAUNCHER);
    launcherIntent.putExtra("ntfId", ntfId);
    launcherIntent.putExtra("title", title);
    launcherIntent.putExtra("message", message);
    launcherIntent.putExtra("appdata", appdata);
    Ti.API.info("service gcm.js title" + title);
    Ti.API.info("service gcm.js message" + message);
    Ti.API.info("service gcm.js appdata" + appdata);
    Ti.API.info("service gcm.js ntfId :" + ntfId);
    ntfId += 1;
    var pintent = Ti.Android.createPendingIntent({
        intent: launcherIntent
    }), notification = Ti.Android.createNotification({
        contentIntent: pintent,
        contentTitle: title,
        contentText: message,
        tickerText: title,
        icon: Ti.App.Android.R.drawable.appicon,
        flags: Ti.Android.FLAG_AUTO_CANCEL | Ti.Android.FLAG_SHOW_LIGHTS
    });
    Ti.Android.NotificationManager.notify(notificationId, notification);
    service.stop();
}(Ti.Android.currentService);