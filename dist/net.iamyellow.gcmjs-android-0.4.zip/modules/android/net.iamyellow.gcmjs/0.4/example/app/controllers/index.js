
var deviceToken = '';

function doClick(e) {
	if (deviceToken) {
		alert('do unregister');
		// unregister not implemented yet
		//require('net.iamyellow.gcmjs').fireUnregister(deviceToken);
	}
}

$.container.open();

if (OS_ANDROID) {
	var gcm = require('net.iamyellow.gcmjs');

	var pendingData = gcm.data;
	if (pendingData && pendingData !== null) {
		// if we're here is because user has clicked on the notification
		// and we set extras for the intent 
		// and the app WAS NOT running
		// (don't worry, we'll see more of this later)
		Ti.API.info('******* data (started) ' + JSON.stringify(pendingData));
	}

	var receivePush = function(ev) {
		Ti.API.info(String.format('receivePush %s', ev.appdata || {}));
		alert(String.format('receivePush' , ev.appdata || {}));
	};

	var deviceTokenSuccess = function(ev) {
		Ti.API.info('deviceTokenSuccess:' + ev.deviceToken);
		deviceToken = ev.deviceToken;
	};

	var deviceTokenError = function(ev) {
		Ti.API.info('deviceTokenError:' + ev.error);
	};

	var dataWhenResume = function(ev) {
		Ti.API.info(String.format('ev.data %s' , ev.data));
	};

	var afterUnregister = function(ev) {
		Ti.API.info(String.format('afterUnregister %s' , ev));
		Ti.API.info('******* unregister ' + ev.deviceToken);
		deviceToken = ''
	};

	var isCallbackMethod = false;

	if (isCallbackMethod) {

		// Method 1 call-back (Original)
		gcm.registerForPushNotifications({
			callback: receivePush,
			success: deviceTokenSuccess,
			error: deviceTokenError,
			unregister: afterUnregister,
			data: dataWhenResume
		});
	} else {

		// Method 2 eventlistener
		gcm.addEventListener('callback', receivePush);
		gcm.addEventListener('success', deviceTokenSuccess);
		gcm.addEventListener('error', deviceTokenError);
		gcm.addEventListener('data', dataWhenResume);
		gcm.addEventListener('unregister', afterUnregister);
		gcm.registerForPushNotifications({});
	}

}


if (OS_IOS) {
	// 表示対象の画像は配列として渡します
	var images = [
		'/images/dummy01.jpg',
		'/images/dummy02.jpg',
		'/images/dummy03.jpg',
		'/images/dummy04.jpg',
		'/images/dummy05.jpg'
	];
	// 背景色とセットで画像一覧を引き渡します
	var view = Titanium.UI.createCoverFlowView({
		top: 20,
		//width: Ti.UI.FILL,
		width: 300,
		height: 120,
		images: images,
		backgroundColor: 'aqua'
	});

	// 画像選択時のイベント
	view.addEventListener('click',function(e){
		Ti.API.info('image clicked: ' + e.index + ', selected is ' + view.selected);  
	});

	// フリックなどで選択中の画像が変わったときのイベント
	view.addEventListener('change',function(e){
		Titanium.API.info('現在の画像: ' + e.index + ', 直近の画像: ' + view.selected);       
	});

	$.container.add(view);
}
